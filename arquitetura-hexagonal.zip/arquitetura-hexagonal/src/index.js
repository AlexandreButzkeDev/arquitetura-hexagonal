import 'dotenv/config'
import { createSupabaseAuthAdapter } from './adapters/supabaseAuthAdapter.js'
import { createSupabaseProfileAdapter } from './adapters/supabaseProfileAdapter.js'
import { createFileSessionAdapter } from './adapters/fileSessionAdapter.js'
import { createCliAdapter } from './adapters/cliAdapter.js'
import AuthService from './core/authService.js'

const SUPABASE_URL = process.env.SUPABASE_URL || ''
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || ''

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('ERRO: `SUPABASE_URL` ou `SUPABASE_ANON_KEY` não configurados. Verifique .env ou variáveis de ambiente.')
  process.exit(1)
}

// create adapters
const authAdapter = createSupabaseAuthAdapter(SUPABASE_URL, SUPABASE_ANON_KEY)
// Profile adapter creates its own client internally; we only pass config.
const profileAdapter = createSupabaseProfileAdapter(SUPABASE_URL, SUPABASE_ANON_KEY)
const sessionAdapter = createFileSessionAdapter('.session.json')
const cli = createCliAdapter()

const service = new AuthService({
  authPort: authAdapter,
  profilePort: profileAdapter,
  sessionPort: sessionAdapter,
  ioPort: cli
})

async function interactiveCli() {
  // respect NONINTERACTIVE
  if (process.env.NONINTERACTIVE === '1') {
    const choice = process.env.TEST_CHOICE || '2'
    const email = process.env.TEST_EMAIL || 'teste@teste.com'
    const senha = process.env.TEST_PASSWORD || '12345678'
    if (choice === '1') {
      await service.login(email, senha, false)
    } else {
      await service.register(email, senha)
      await service.login(email, senha, false)
    }
    return
  }

  try {
    const choice = await cli.ask('Digite 1 para usuário cadastrado, 2 para usuário não cadastrado: ')
    if (choice === '1') {
      const email = await cli.ask('Email: ')
      const senha = await cli.ask('Senha: ')
      await service.login(email, senha)
    } else if (choice === '2') {
      const email = await cli.ask('Email para cadastro: ')
      const senha = await cli.ask('Senha para cadastro: ')
      const reg = await service.register(email, senha)
      if (reg.success) {
        cli.print('Cadastro realizado com sucesso — agora tentando login...')
      } else {
        cli.print('Falha no cadastro.')
        if (reg.error) cli.print('Erro: ' + (reg.error.message || JSON.stringify(reg.error)))
      }
      await service.login(email, senha)
    } else {
      cli.print('Opção inválida.')
    }
  } finally {
    cli.close()
  }
}

;(async () => {
  const restored = await service.restoreSession()
  if (restored.restored && restored.user) {
    try {
      const choice = await cli.ask(`Sessão encontrada para ${restored.user.email}.\n1) Continuar com essa sessão\n2) Deslogar e reiniciar\n3) Entrar com outro usuário\n4) Cadastrar novo usuário\nDigite 1/2/3/4: `)
      if (choice === '1') {
        cli.print('Continuando com sessão existente.')
        const profile = await profileAdapter.findByUserId(restored.user.id)
        cli.print('Profile: ' + JSON.stringify(profile))
        cli.close()
        return
      }
      if (choice === '2') {
        await service.signOut()
        cli.print('Sessão encerrada. Reiniciando fluxo...')
        await interactiveCli()
        return
      }
      if (choice === '3') {
        const email = await cli.ask('Email: ')
        const senha = await cli.ask('Senha: ')
        await service.login(email, senha)
        return
      }
      if (choice === '4') {
        const email = await cli.ask('Email para cadastro: ')
        const senha = await cli.ask('Senha para cadastro: ')
        const ok = await service.register(email, senha)
        if (ok.success) cli.print('Cadastro realizado com sucesso — agora tentando login...')
        else cli.print('Falha no cadastro.')
        await service.login(email, senha)
        return
      }
      cli.print('Opção inválida. Reiniciando fluxo interativo...')
      await interactiveCli()
      return
    } catch (e) {
      // fall through to interactive
    }
  }

  interactiveCli().catch((err) => {
    console.error('Erro inesperado:', err)
    process.exit(1)
  })
})()
