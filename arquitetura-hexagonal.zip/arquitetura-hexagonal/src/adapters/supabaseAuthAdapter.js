import { createClient } from '@supabase/supabase-js'

// Auth adapter for Supabase. Note: we intentionally do NOT expose the raw
// Supabase client here to keep the core/service decoupled from the provider.
export function createSupabaseAuthAdapter(url, anonKey) {
  const supabase = createClient(url, anonKey)

  return {
    signUp: async (email, password) => {
      const { data, error } = await supabase.auth.signUp({ email, password })
      return error ? { error } : { user: data.user, session: data.session }
    },
    signIn: async (email, password) => {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      return error ? { error } : { user: data.user, session: data.session }
    },
    getUser: async () => {
      const { data, error } = await supabase.auth.getUser()
      return error ? { error } : { user: data.user }
    },
    setSession: async (session) => {
      try {
        await supabase.auth.setSession({
          access_token: session.access_token,
          refresh_token: session.refresh_token
        })
        return { ok: true }
      } catch (error) {
        return { error }
      }
    },
    signOut: async () => {
      await supabase.auth.signOut()
    }
  }
}
