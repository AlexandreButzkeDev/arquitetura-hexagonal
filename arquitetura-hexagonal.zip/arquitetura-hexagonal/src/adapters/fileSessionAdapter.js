import fs from 'fs'
import path from 'path'

export function createFileSessionAdapter(filename = '.session.json') {
  const SESSION_FILE = path.resolve(process.cwd(), filename)

  return {
    save: async (session) => {
      const toSave = {
        access_token: session.access_token,
        refresh_token: session.refresh_token
      }
      fs.writeFileSync(SESSION_FILE, JSON.stringify(toSave))
    },
    restore: async () => {
      try {
        if (!fs.existsSync(SESSION_FILE)) return null
        const raw = fs.readFileSync(SESSION_FILE, 'utf8')
        return JSON.parse(raw)
      } catch (e) {
        return null
      }
    },
    clear: async () => {
      try {
        if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE)
      } catch (e) {
        // ignore
      }
    }
  }
}
