import readline from 'readline'

export function createCliAdapter() {
  let rl
  function ensure() {
    if (!rl) rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  }

  return {
    ask: (q) => {
      ensure()
      return new Promise((res) => rl.question(q, (ans) => res(ans && ans.trim())))
    },
    print: (msg) => console.log(msg),
    close: () => { if (rl) { rl.close(); rl = null } }
  }
}
