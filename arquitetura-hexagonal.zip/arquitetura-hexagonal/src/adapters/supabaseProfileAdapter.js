import { createClient } from '@supabase/supabase-js'

// This adapter encapsulates Supabase-specific queries. It creates its own
// Supabase client internally so the rest of the app doesn't need a raw client.
export function createSupabaseProfileAdapter(url, anonKey) {
  const sb = createClient(url, anonKey)

  return {
    create: async (profile) => {
      const { error } = await sb.from('profiles').insert([profile])
      if (error) throw error
      return true
    },
    findByUserId: async (userId) => {
      const { data, error } = await sb.from('profiles').select('*').eq('user_id', userId).single()
      if (error) return null
      return data
    }
  }
}
