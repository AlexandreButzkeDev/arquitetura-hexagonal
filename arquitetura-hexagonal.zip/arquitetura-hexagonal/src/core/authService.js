// Core application service (ports-driven) for authentication flows

export default class AuthService {
  constructor({ authPort, profilePort, sessionPort, ioPort }) {
    this.auth = authPort
    this.profile = profilePort
    this.session = sessionPort
    this.io = ioPort
  }

  async register(email, password) {
    const res = await this.auth.signUp(email, password)
    if (!res || res.error) return { success: false, error: res?.error }

    // create profile (optional)
    try {
      await this.profile.create({ user_id: res.user.id })
    } catch (e) {
      // non-fatal
      this.io.print(`Erro ao criar profile: ${e.message}`)
    }

    return { success: true, user: res.user }
  }

  async login(email, password, interactive = true) {
    const res = await this.auth.signIn(email, password)
    if (!res || res.error) return { success: false, error: res?.error }

    if (res.session) {
      await this.session.save(res.session)
    }

    const profile = await this.profile.findByUserId(res.user.id)

    if (interactive) {
      const ans = await this.io.ask(
        "Pressione 'x' para deslogar agora, ou Enter para continuar: "
      )
      if ((ans || '').toLowerCase() === 'x') {
        await this.auth.signOut()
        await this.session.clear()
        this.io.print('Deslogado.')
      }
    }

    return { success: true, user: res.user, profile }
  }

  async restoreSession() {
    const s = await this.session.restore()
    if (!s) return { restored: false }
    const set = await this.auth.setSession(s)
    if (set?.error) return { restored: false }
    const user = await this.auth.getUser()
    return { restored: true, user: user?.user }
  }

  async signOut() {
    await this.auth.signOut()
    await this.session.clear()
  }
}
