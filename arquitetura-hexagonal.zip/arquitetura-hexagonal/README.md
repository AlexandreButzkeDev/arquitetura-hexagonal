# Hexagonal Supabase CLI

Small CLI demonstrating login/registration with Supabase using Hexagonal Architecture (ports & adapters).

Quick start (Windows PowerShell):

1. Copy `.env.example` to `.env` and fill `SUPABASE_URL` and `SUPABASE_ANON_KEY`.

```powershell
cd c:/Users/Acer/Desktop/TCC/arquitetura-hexagonal
npm install
npm run start
```

Non-interactive test run (PowerShell):

```powershell
npx cross-env NONINTERACTIVE=1 TEST_CHOICE=2 TEST_EMAIL=teste@teste.com TEST_PASSWORD=12345678 npm run start
```

Files of interest:
- `src/core/authService.js` — application/core logic (ports used here).
- `src/adapters/` — adapters for Supabase, file session, and CLI.
- `src/index.js` — wiring and entrypoint.
